Correr comando: make Servidor && make Cliente

ejecutar servidor:

./Servidor 2407 database.txt

ejecutar cliente: 

./Cliente ip_server port_server vote_file
